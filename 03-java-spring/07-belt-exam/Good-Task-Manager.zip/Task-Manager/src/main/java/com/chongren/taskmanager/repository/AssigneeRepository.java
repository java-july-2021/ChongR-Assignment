package com.chongren.taskmanager.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.chongren.taskmanager.model.Assignee;

@Repository
public interface AssigneeRepository extends CrudRepository<Assignee, Long>{
	
	List<Assignee> findAll();
}
