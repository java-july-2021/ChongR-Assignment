package com.chongren.taskmanager.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;

@Entity
@Table(name="assignees")
public class Assignee {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	
	@Size(max=15)
	private String firstName;
	
	@Size(max=30)
	private String lastName;
	
	//============ Constructor ============//
	
	public Assignee() {

	}


	//============= 12M ===============//
	@OneToMany(mappedBy="assigned", cascade=CascadeType.ALL, fetch=FetchType.LAZY)  //mappedBy the variable in User user<-  in the Idea side
	private List<Task> taskAssigned;
	
	
	//============ Getter & Setter ============//

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public List<Task> getTaskAssigned() {
		return taskAssigned;
	}

	public void setTaskAssigned(List<Task> taskAssigned) {
		this.taskAssigned = taskAssigned;
	}

	
    
	
	
	
}
