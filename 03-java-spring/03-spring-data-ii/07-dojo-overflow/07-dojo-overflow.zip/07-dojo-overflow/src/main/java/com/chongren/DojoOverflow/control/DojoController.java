package com.chongren.DojoOverflow.control;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.chongren.DojoOverflow.model.Answer;
import com.chongren.DojoOverflow.model.Question;
import com.chongren.DojoOverflow.service.DojoService;

@Controller
public class DojoController {
	@Autowired
	private DojoService dServ;
	
	//------------------------- Home Page -----------------------//
		@RequestMapping("/")
		public String index(Model viewModel) {
			List<Question> allQuestion = this.dServ.showAllQuestion();
			viewModel.addAttribute("allQuestion", allQuestion);
			return "dashboard.jsp";
		}
		
	//------------------------- New Question Page -----------------------//
		@GetMapping("/questions/new")
		public String newQuestion(@ModelAttribute("quesstion") Question question) {
			return "NewQuestion.jsp";
		}
		
		@PostMapping("/newquestion")
		public String processNewQuestion(@Valid @RequestParam("question")String question, @RequestParam("tag")String tag, BindingResult result) {
			//Valid, if tag exsit, add to question; if not, create tag first then add to question. Each question can have max 3 tags
			
			Question newQuestion = new Question();
			newQuestion.setQuestion(question);
			return "redirect:/";
			
		}
		
		
	//------------------------- New Answer Page -----------------------//
		@GetMapping("/questions/{id}")
		public String newQuestion(@PathVariable("id")Long id, Model viewModel) {
			viewModel.addAttribute("question", this.dServ.findSingleQuestion(id));
			return "NewAnswer.jsp";
		}
		
		@PostMapping("/newanswer")
		public String processNewQuestion(@Valid @RequestParam("answer")String answer, BindingResult result) {
			//Valid, if tag exsit, add to question; if not, create tag first then add to question. Each question can have max 3 tags
			
			Answer newAnswer = new Answer();
			newAnswer.setAnswer(answer);
			return "redirect:/";
			
		}
		
}
